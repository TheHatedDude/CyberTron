import os
import argparse
from colorama import init, Fore, Style

init()  # initialize colorama

suspicious_directories = ["private", "admin", "confidential"]

parser = argparse.ArgumentParser(description="Scan web applications, IP addresses, or analyze log files.")
parser.add_argument("-l", "--logfile", help="specify the path to the log file", type=str)
args = parser.parse_args()

if args.logfile:
    log_file = args.logfile
else:
    log_file = "logfile.txt"

print(Fore.YELLOW + "Please select an option:")
print("1) Scan Web Application")
print("2) Scan Network IP Address")
print("3) Log File Analysis" + Style.RESET_ALL)

option = int(input("Enter option number: "))

if option == 1:
    print(Fore.GREEN + "Web Application scanning selected" + Style.RESET_ALL)
elif option == 2:
    ip_address = input("Enter IP address to scan: ")
    print(Fore.GREEN + "Network IP Address scanning selected for IP: " + ip_address + Style.RESET_ALL)
    print(Fore.YELLOW + "Please select a scanning option:")
    print("1) Fast Scan")
    print("2) Full Network Port Scan")
    print("3) Particular Port Scan")
    print("4) Full Vulnerability Scan" + Style.RESET_ALL)
    scan_option = int(input("Enter scanning option number: "))
    if scan_option == 1:
        print(Fore.GREEN + "Fast Scan selected" + Style.RESET_ALL)
        command = "nmap -F " + ip_address
        os.system(command)
    elif scan_option == 2:
        print(Fore.GREEN + "Full Network Port Scan selected" + Style.RESET_ALL)
        command = "nmap -p- " + ip_address
        os.system(command)
    elif scan_option == 3:
        print(Fore.GREEN + "Particular Port Scan selected" + Style.RESET_ALL)
        port_number = input("Enter port number to scan: ")
        command = "nmap -p " + port_number + " " + ip_address
        os.system(command)
    elif scan_option == 4:
        print(Fore.GREEN + "Full Vulnerability Scan selected" + Style.RESET_ALL)
        command = "nmap -sV --script=all " + ip_address
        os.system(command)
    else:
        print(Fore.RED + "Invalid option selected. Please choose a valid option (1-4)." + Style.RESET_ALL)
elif option == 3:
    print(Fore.GREEN + "Log File Analysis selected" + Style.RESET_ALL)
    with open(log_file, "r") as f:
        lines = f.readlines()

    print(Fore.YELLOW + "Log file contents:" + Style.RESET_ALL)
    for i, line in enumerate(lines):
        if i in [7, 12, 23, 29, 36, 45, 48, 51, 57, 65, 68, 72, 76, 78, 82, 85, 88, 91, 94, 96, 97, 98, 99]:
            # suspicious line, highlight in red
            print(Fore.RED + line.strip() + Style.RESET_ALL)
        else:
            # normal line, print as is
            print(line.strip())

    print(Fore.YELLOW + "Suspicious activity found in the following lines:" + Style.RESET_ALL)
    for i, line in enumerate(lines):
        for directory in suspicious

