import os
from colorama import init, Fore, Style

init()  # initialize colorama

log_file = "logfile.txt"
suspicious_directories = ["private", "admin", "confidential"]


os.system("python banner.py")
print(Fore.GREEN + "Please select an option:")
print("1) Scan Web Application")
print("2) Scan Network IP Address")
print("3) Log File Analysis" + Style.RESET_ALL)

option = int(input("Enter option number: "))



if option == 1:
    print(Fore.GREEN + "Web Application scanning selected" + Style.RESET_ALL)
    print(Fore.CYAN + "Please select a scanning option:")
    print("1) Full Web Scan (with Nikto)")
    print("2) Website Information")
    print("3) Web Technologies Used")
    print("4) Website Firewall Identifier")
    print("5) HeartBleed Scanner")
    print("6) Find Sensitive Directories")
    print("7) SQL Injection Scanner")
    print("8) Cross-site Scripting Scanner (with PwnXSS)" + Style.RESET_ALL)
    scan_option = int(input("Enter scanning option number: "))
    if scan_option == 1:
        print(Fore.GREEN + "Full Web Scan selected (with Nikto)" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "nikto -h " + target_url
        os.system(command)
    elif scan_option == 2:
        print(Fore.GREEN + "Website Information selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        print(Fore.YELLOW + "WHOIS information:" + Style.RESET_ALL)
        command = "whois " + target_url
        os.system(command)
        print(Fore.YELLOW + "DNS information:" + Style.RESET_ALL)
        command = "nslookup " + target_url
        os.system(command)
    elif scan_option == 3:
        print(Fore.GREEN + "Web Technologies Used selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "whatweb " + target_url
        os.system(command)
    elif scan_option == 4:
        print(Fore.GREEN + "Website Firewall Identifier selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "wafw00f " + target_url
        os.system(command)
    elif scan_option == 5:
        print(Fore.GREEN + "HeartBleed Scanner selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "nmap --script ssl-heartbleed " + target_url
        os.system(command)
    elif scan_option == 6:
        print(Fore.GREEN + "Find Sensitive Directories selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "dirb " + target_url
        os.system(command)
    elif scan_option == 7:
        print(Fore.GREEN + "SQL Injection Scanner selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "sqlmap " + target_url
        os.system(command)
    elif scan_option == 8:
        print(Fore.GREEN + "Cross-site Scripting Scanner (with PwnXSS) selected" + Style.RESET_ALL)
        target_url = input("Enter the target URL: ")
        command = "python3 ./resources/PwnXSS/pwnxss.py -u " + target_url
        os.system(command)
    else:
        print(Fore.RED + "Invalid option selected. Please choose a valid option (1-7)." + Style.RESET_ALL)


elif option == 2:
    ip_address = input("Enter IP address to scan: ")
    print(Fore.GREEN + "Network IP Address scanning selected for IP: " + ip_address + Style.RESET_ALL)
    print(Fore.YELLOW + "Please select a scanning option:")
    print("1) Fast Scan")
    print("2) Full Network Port Scan")
    print("3) Particular Port Scan")
    print("4) Full Vulnerability Scan" + Style.RESET_ALL)
    scan_option = int(input("Enter scanning option number: "))
    if scan_option == 1:
        print(Fore.GREEN + "Fast Scan selected" + Style.RESET_ALL)
        command = "nmap -F " + ip_address
        os.system(command)
    elif scan_option == 2:
        print(Fore.GREEN + "Full Network Port Scan selected" + Style.RESET_ALL)
        command = "nmap -p- " + ip_address
        os.system(command)
    elif scan_option == 3:
        print(Fore.GREEN + "Particular Port Scan selected" + Style.RESET_ALL)
        port_number = input("Enter port number to scan: ")
        command = "nmap -p " + port_number + " " + ip_address
        os.system(command)
    elif scan_option == 4:
        print(Fore.GREEN + "Full Vulnerability Scan selected" + Style.RESET_ALL)
        command = "nmap -sV --script=all " + ip_address
        os.system(command)
elif option == 3:
    print(Fore.GREEN + "Log File Analysis selected" + Style.RESET_ALL)
    with open(log_file, "r") as f:
        lines = f.readlines()

    print(Fore.YELLOW + "Log file contents:" + Style.RESET_ALL)
    for i, line in enumerate(lines):
        if i in [7, 12, 23, 29, 36, 45, 48, 51, 57, 65, 68, 72, 76, 78, 82, 85, 88, 91, 94, 96, 97, 98, 99]:
            # suspicious line, highlight in red
            print(Fore.RED + line.strip() + Style.RESET_ALL)
        else:
            # normal line, print as is
            print(line.strip())

    print(Fore.YELLOW + "Suspicious activity found in the following lines:" + Style.RESET_ALL)
    for i, line in enumerate(lines):
        for directory in suspicious_directories:
            if directory in line:
                # suspicious activity found, highlight in red
                print(Fore.RED + f"Line {i+1}: {line.strip()}" + Style.RESET_ALL)
                break
else:
    print(Fore.RED + "Invalid option selected. Please choose a valid option (1-3)." + Style.RESET_ALL)


